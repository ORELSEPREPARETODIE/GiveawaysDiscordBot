# [Want One With Giveaway Requirements and Bonus Enteries?](https://github.com/ZeroDiscord/Giveaway)
- [Check Out This Video!](https://www.youtube.com/watch?v=9E6gREwQH6o)

**This Giveaway bot was created by 0_0#6666**

**IN CONFIG.JSON DO NOT CHANGE ANY VARIABLE THE everyoneMention VARIABLE IS FOR THE EVERYONE MENTION WHEN A NEW GIVEAWAY OCCURS AND EVERYTHING ELSE IS SELF EPLAINATORY JUST CHANGE THE VALUES 
INSIDE "" TO MAKE YOUR BOT FUNCTION PROPERLY!**
# Links
- 🔗 [Youtube Channel](https://www.youtube.com/channel/UCF9E-xef9jL9QgziZRDHKKQ)
- [Support Server Link](https://discord.gg/ARu4hr6hJw)
# Copyright 
Copyright 2020 © All RIghts are Reserved | If you are using any part of code please give me credits for the same. Thanks

# License
**ngnix 2020 all rights reserved**

**NOTE FOR GLITCH HOSTERS 
`` THIS BOT DIES IF YOU DON'T USE IT EVERY 5 MINUTES CAN BE EASILY RE-HOSTED BY REGENERATING THE TOKEN AND REPPLACING IT 
IF YOU WANT A SCRIPT THAT PREVENTS THIS JOIN THE SERVER ABOVE AND DM 0_0#6666 THIS MIGHT GET YOUR PROJECT SUSPENDED BUT YOU CAN ALWAYS
MAKE A NEW ONE USING MY TUTORIAL :D``**
``IF YOU DO NOT USE A COMMAND EVERY HALF AN HOUR ON REPL.IT HOSTING THE BOT DIES, CAN BE REVIVED BY RESTARTING IT``

# Host On Repl.it
[![Use on Repl.it](https://repl.it/badge/github/ZeroDiscord/GiveawayBot)](https://repl.it/github/ZeroDiscord/GiveawayBot)
