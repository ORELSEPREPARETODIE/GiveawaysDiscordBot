module.exports = {
    version: require('./package.json').version,
    GiveawaysManager: require('./src/Manager')
};
